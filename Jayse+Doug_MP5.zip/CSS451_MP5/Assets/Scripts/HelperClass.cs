﻿namespace HelperNamespace
{
    public enum Mode
    {
        Mesh,
        Cylinder
    }
}